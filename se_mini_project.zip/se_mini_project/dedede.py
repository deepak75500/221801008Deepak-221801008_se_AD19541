from flask import Flask, render_template, request, redirect, url_for, session
import firebase_admin
from firebase_admin import credentials, auth, db
import os

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "your_secret_key")

cred = credentials.Certificate(os.getenv("FIREBASE_CREDENTIALS_PATH", r"C:\Users\Deepa\Downloads\fir-76d09-firebase-adminsdk-qdjnu-cb873358f9.json"))
firebase_admin.initialize_app(cred, {
    'databaseURL': os.getenv("FIREBASE_DATABASE_URL", 'https://fir-76d09-default-rtdb.firebaseio.com')  
})

@app.route('/')
def login_page():
    return render_template("login12.html")

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    turf_name = request.form.get("turf_name")
    print("Turf name received:", turf_name)

    session['turf_name'] = turf_name

    if '@' not in username or '.' not in username:
        return "Please enter a valid email address.", 400

    try:
        user = auth.get_user_by_email(username)
        session['user_id'] = user.uid 
        return redirect(url_for('show_bookings'))
    except auth.AuthError:
        return "Login failed: User not found or incorrect credentials", 401
    except Exception as e:
        return f"An unexpected error occurred: {str(e)}", 500

# Show customer bookings only if logged in
@app.route('/show_bookings')
def show_bookings():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))  # Redirect to login if not logged in

    # Retrieve turf name from session
    turf_name = session.get('turf_name')
    print("Current turf_name:", turf_name)

    bookings_ref = db.reference('bookings')
    all_bookings = bookings_ref.get()

    # Debugging output
    print("All bookings data:", all_bookings)

    # Filter bookings by turf name
    bookings_list = [
        dict({'id': key}, **details)
        for key, details in all_bookings.items()
        if isinstance(details, dict) and details.get("turf_name") == turf_name
    ] if all_bookings else []

    return render_template("show.html", bookings=bookings_list)

# Log out user and clear session
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('turf_name', None)
    return redirect(url_for('login_page'))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
