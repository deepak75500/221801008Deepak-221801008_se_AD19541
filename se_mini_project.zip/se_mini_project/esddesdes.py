from flask import Flask, request, redirect, url_for, render_template, session, send_from_directory
import firebase_admin
from firebase_admin import credentials, auth, db
import random
import smtplib
from flask_mail import Mail, Message
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import time
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "your_secret_key")
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = "r9691171@gmail.com"  
app.config['MAIL_PASSWORD'] = "hnjk kgqq wqqx gdpq"  
mail = Mail(app)
cred = credentials.Certificate(r"C:\Users\Deepa\Downloads\fir-76d09-firebase-adminsdk-qdjnu-cb873358f9.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://fir-76d09-default-rtdb.firebaseio.com'  
})
otp_storage = {}
def send_otp_via_email(email, otp):
    msg = MIMEMultipart()
    msg['Subject'] = 'Your OTP Code'
    msg['From'] = "r9691171@gmail.com"
    msg['To'] = email
    body = f"Your OTP is: {otp}. It is valid for 5 minutes."
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login("r9691171@gmail.com", "hnjk kgqq wqqx gdpq")
            server.send_message(msg)
            print(f"OTP sent to {email}")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route('/')
def login_page():
    data = r"downloada.jpg"
    return render_template("login.html", data=data)
@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get("username")
    password = request.form.get("password")
    user = auth.create_user(email=username, password=password)
    otp = random.randint(100000, 999999)
    otp_storage[user.uid] = {
        'otp': otp,
        'timestamp': time.time()
    }
    send_otp_via_email(username, otp)
    session['uid'] = user.uid 
    return redirect(url_for('verify'))
@app.route('/login', methods=['POST'])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    user = auth.get_user_by_email(username)
    otp = random.randint(100000, 999999)
    otp_storage[user.uid] = {
        'otp': otp,
        'timestamp': time.time()
    }
    send_otp_via_email(username, otp)
    session['uid'] = user.uid  
    return redirect(url_for('verify'))
@app.route('/verify')
def verify():
    return render_template("verify.html")  
@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    uid = session.get('uid')
    entered_otp = request.form.get("otp")

    if uid in otp_storage:
        otp_data = otp_storage[uid]
        if otp_data['otp'] == int(entered_otp) and (time.time() - otp_data['timestamp'] < 300):
            del otp_storage[uid]
            session['user'] = uid
            return redirect(url_for('main_page'))
        else:
            return "Invalid or expired OTP!", 400
    else:
        return "No OTP sent for this user!", 400
@app.route('/turf_locations')
def turf_locations():
    return send_from_directory(os.path.dirname(__file__), 'turf_locations_tamilnadu.json')
def send_confirmation_email(name, email, date_time):
    msg = Message("Booking Confirmation", sender='r9691171@gmail.com', recipients=[email]) 
    msg.body = f"Hello {name},\n\nYour booking for {date_time} has been confirmed."
    mail.send(msg)
@app.route('/booking')
def booking():
    turf_name = request.args.get('name', 'Unknown Turf')
    return render_template("book.html", turf_name=turf_name)
@app.route('/submit_booking', methods=['POST'])
def submit_booking():
    name = request.form['name']
    email = request.form['email']
    phone_number = request.form['phone_number']
    date_time = request.form['date_time']
    turf_name = request.form['turf_name']
    bookings_ref = db.reference('bookings')
    new_booking_ref = bookings_ref.push()
    new_booking_ref.set({
        'name': name,
        'email': email,
        'phone_number': phone_number,
        'date_time': date_time,
        'turf_name': turf_name
    })

    send_confirmation_email(name, email, date_time)
    return redirect(url_for('booking_confirmation'))
@app.route('/booking_confirmation')
def booking_confirmation():
    return render_template("confirm.html")
@app.route('/main')
def main_page():
    return render_template("rffrrf.html")
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login_page'))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
