import time
import imaplib
import email
from email.header import decode_header
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import re
def asss(rert):
    message = rert

    otp_match = re.search(r'\b\d{6}\b', message)

    if otp_match:
        otp = otp_match.group(0)
        print(f"Extracted OTP: {otp}")
    else:
        print("No OTP found.")
    return otp

GMAIL_USER = 'deepak123mastermind@gmail.com' 
GMAIL_PASSWORD = 'upuj wgii wcpc fcps' 

FLASK_APP_URL = 'http://127.0.0.1:5000/' 
driver = webdriver.Chrome()  
driver.get(FLASK_APP_URL)

username_input = driver.find_element(By.NAME, 'username')
password_input = driver.find_element(By.NAME, 'password')
username_input.send_keys(GMAIL_USER)  
password_input.send_keys(GMAIL_PASSWORD) 
password_input.send_keys(Keys.RETURN) 

time.sleep(3)
def get_otp_from_email():
    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login(GMAIL_USER, GMAIL_PASSWORD)
    mail.select('inbox')

    status, messages = mail.search(None, '(FROM "r9691171@gmail.com" SUBJECT "Your OTP Code")')  
    email_ids = messages[0].split()
    latest_email_id = email_ids[-1] 

    status, msg_data = mail.fetch(latest_email_id, '(RFC822)')
    msg = email.message_from_bytes(msg_data[0][1])
    
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == 'text/plain':
                body = part.get_payload(decode=True).decode()
                break
    else:
        body = msg.get_payload(decode=True).decode()

    otp_line = [line for line in body.splitlines() if 'Your OTP is:' in line]
    if otp_line:
        otp = otp_line[0].split(': ')[1].strip()
        return otp
    return None

otp = get_otp_from_email()
if otp:
    print(f"Retrieved OTP: {otp}")
    print(otp)
    otp=asss(otp)
    otp_input = driver.find_element(By.NAME, 'otp') 
    otp_input.send_keys(otp)
    otp_input.send_keys(Keys.RETURN) 

    time.sleep(3) 

    if "main" in driver.current_url:
        print("Successfully navigated to the main page!")
    else:
        print("Failed to navigate to the main page.")

   
    print("Current page title:", driver.title)
else:
    print("Failed to retrieve OTP.")
print("test case successfully")
driver.quit()
